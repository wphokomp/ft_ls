#include <unistd.h>

void	putchar(char c)
{
	write(1, &c, 1);
}

int		main(int argc, char **argv)
{
	int		i;
	
	i = 0;
	while (argv[1][i] != '\0')
	{
		if (argv[1][i] == " " || argv[1][i] == "	")
		{
			ft_putchar("\n");
			break;
		}
		else
			ft_putchar(argv[1][i]);
	}
}